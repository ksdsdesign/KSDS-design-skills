# Third-party notices

- Mediabunny 1.51.0 — MPL-2.0. Original license, package metadata, and corresponding source are included in `third-party/mediabunny/`. The plugin's integration bridge is also included. Upstream: https://github.com/Vanilagy/mediabunny
- lottie-web 5.12.2 — MIT. License text is included in `third-party/lottie-web/LICENSE.md`. Upstream: https://github.com/airbnb/lottie-web/tree/v5.12.2
- blake3-wasm 2.1.5 — MIT. Original license is included in `third-party/blake3-wasm/LICENSE`.
- 内置字体、撒花和顶光设计素材：发布者于 2026-11-02 确认已有对外公开分发授权。该确认不替代第三方库各自的许可。

本候选包不授予使用其他用户设计内容的权利。上传、公开或转发设计前，请自行确认该设计的使用权限。
