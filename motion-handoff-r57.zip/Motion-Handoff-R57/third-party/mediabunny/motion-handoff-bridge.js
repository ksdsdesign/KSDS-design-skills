import {
  BufferTarget,
  CanvasSource,
  EncodedPacket,
  EncodedVideoPacketSource,
  Output,
  Quality,
  WebMOutputFormat,
} from "mediabunny";

globalThis.MotionHandoffMedia = {
  BufferTarget,
  CanvasSource,
  EncodedPacket,
  EncodedVideoPacketSource,
  Output,
  Quality,
  WebMOutputFormat,
};
