# Error Handling — 90s Hiphop Style

This skill relies on the image generation or image editing capability available in the user's runtime environment. If generation fails, use the table below as a troubleshooting guide.

| Symptom | Possible Cause | Suggested Action |
|---|---|---|
| Image cannot be read | Invalid file path, unsupported image format, or corrupted upload | Ask the user to upload a clear PNG/JPG/WebP image again |
| Generation is blocked | The input image or prompt violates the active model/provider policy | Explain that the image cannot be processed and ask for a different photo |
| Rate limit / 429 | The image generation provider is temporarily limiting requests | Wait and retry later |
| Timeout | The input image is too large or the provider is slow | Resize/compress the input image or retry with a smaller output size |
| Result does not match the style | Model drift or weak style adherence | Strengthen the prompt around thick black outlines, flat colors, red background, hard shadows, and vintage screen-print texture |
| Metallic accessories look dull | Missing highlight emphasis | Add explicit instructions for silver/cyan highlights, star sparkles, and blingbling reflections |
| Subject identity changes too much | Style conversion overpowers the source photo | Add stronger wording to preserve facial features, pose, clothing, accessories, and silhouette |

General rule: keep the user's original subject recognizable while applying the 90s retro comic visual language.
