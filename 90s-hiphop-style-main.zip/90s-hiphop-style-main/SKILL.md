---
name: 90s-hiphop-style
description: Transform uploaded photos into a 90s hiphop retro American comic / neo-pop street illustration style. Trigger when the user uploads a photo and asks for "复古美漫风格", "90s hiphop style", "retro pop portrait", "新波普街头漫画", or similar visual style conversion.
---

# 90s Hiphop Style

Transform uploaded photos into a **90s hiphop retro American comic / neo-pop street illustration style**.

The output should feel like a vintage rap album cover: bold black outlines, saturated flat colors, hard-edged shadows, red poster energy, screen-print texture, and shiny metallic highlights.

## Usage

When the user uploads a photo and asks for this style, convert the uploaded image into the target visual style.

Example user prompts:

```text
帮我变成复古美漫风格
转成 90 年代嘻哈风
转成复古波普风
新波普街头漫画
90s hiphop style
retro pop portrait
```

## Execution Flow

1. Use the user's uploaded photo as the source image for image-to-image conversion (not text-to-image).
2. Read the original image dimensions and match the closest supported output aspect ratio (1:1, 3:4, 4:3, 9:16, 16:9).
3. Apply the full style prompt below to transform the source image.
4. If the user adds extra requests (e.g., "change background to blue", "add a gold chain"), append those at the end of the prompt.
5. Output one newly generated image. Do not overwrite the original.

## Full Style Prompt (Must Not Be Simplified)

Apply this complete style direction verbatim — do not shorten, paraphrase, or reduce it:

```text
将这张照片完全重绘为高对比度美式 90 年代复古潮流插画、新波普街头漫画风格、复古说唱专辑封面插画质感。具体要求：1) 线条：所有物体、皮肤、服装、饰品边缘使用厚重均匀的纯黑色粗轮廓线，硬朗锋利，无模糊笔触；2) 色彩：极致高饱和纯色平涂，无柔和渐变，明暗一刀切硬分界——皮肤用暖棕焦糖色块，阴影为纯深黑块；背景改为单一正红高饱和纯色；3) 光影：硬边二分光影，无灰调过渡，亮面暗面两块色块直接切割，高光为锐利块状反光；金属饰品用冷银、亮青蓝高光，添加十字星闪光和细碎亮斑光晕，blingbling 金属反光质感；4) 质感：轻微复古颗粒胶片噪点、复古丝网印刷做旧质感、哑光平涂色块、完全矢量插画质感，无油画水彩笔触；5) 元素：保留原照片的人物特征、构图姿态和关键配饰，手部肌肉块面化简化概括，造型夸张潮流，嘻哈街头美学。整体呈现老式丝网印刷、复古说唱专辑封面的强平面印刷质感。
```

## Generation Guidelines

- Keep the original subject recognizable: facial features, pose, clothing, accessories, and silhouette must remain identifiable.
- Do not add text, logos, or brand identifiers that were not in the original photo.
- For children and pets, preserve their natural age and species characteristics.
- Do not use 3D rendering, smooth digital gradients, oil painting, or watercolor effects.
- The result should look like printed retro comic art, not a clean modern vector illustration.

## Output

Return the generated image. Avoid outputting both a bare URL and an image preview simultaneously to prevent double-rendering.
