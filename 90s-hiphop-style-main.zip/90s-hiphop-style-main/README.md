这是一项将图片转化为90年代嘻哈复古美漫风的工具。任意写真照片上传后，输入「帮我变成复古美漫风格」，即可将其变为美漫风格。

This tool transforms photos into a 1990s hip-hop-inspired retro American comic book style. Simply upload any portrait and enter the prompt "Turn me into a retro American comic book style" to convert the image.
<img width="2430" height="1080" alt="Frame 10" src="https://github.com/user-attachments/assets/1f110763-f4df-4ddd-86cd-89b4e1b8ee79" />



## Preview Style

Retro American comic energy
具有复古美式漫画风格的风格/氛围
Bold outline-heavy visual language
以粗线条为主的视觉风格
Saturated colors and poster-like contrast
饱和的色彩与强烈的对比度，宛如海报一般。
Shiny metallic highlights when the source image contains jewelry, chains, glasses, cars, helmets, or accessories
如果原始图像中包含珠宝、项链、眼镜、汽车、头盔或各种配饰，那么处理后的图像会呈现出闪亮的金属质感。

## Installation

如果您的平台支持从 GitHub 安装技能，请直接使用此仓库 URL：
If your platform supports installing skills from GitHub, use this repository URL directly:

```text
https://github.com/ASATELLITE/90s-hiphop-style
```
Download or clone this repository, then place the `90s-hiphop-style` folder into the skills directory used by your AI assistant or agent platform.

Generic example:

```bash
mkdir -p /path/to/your/skills
cp -R 90s-hiphop-style /path/to/your/skills/90s-hiphop-style
```


## Usage
Upload a photo and say/上传一张照片并说


```text
帮我变成复古美漫风格
```

该工具会将上传的图像转换为目标风格。
The skill will convert the uploaded image into the target retro comic style.



## File Structure

```text
90s-hiphop-style/
├── README.md
├── SKILL.md
├── manifest.json
└── references/
    └── error-handling.md
```

